# Import the NumPy fix first
from . import numpy_fix
