# Apply NumPy fix first
from . import numpy_compat
